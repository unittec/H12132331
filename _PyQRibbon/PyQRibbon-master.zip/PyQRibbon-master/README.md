# PyQRibbon

PyQRibbon是一个实现了ribbon菜单的控件

## 安装

```bash
pip install PyQRibbon
```

## 截图

![screen](https://raw.githubusercontent.com/luolingchun/PyQRibbon/master/screen/1.png)